package com.slidingwindow.main;

import java.sql.Timestamp;
import java.util.List;

public class SlidingWindowQueue {

	
	public int value;
	
	public Timestamp dateTime;
	
	

	public int getValue() {
		return value;
	}


	public void setValue(int value) {
		this.value = value;
	}


	public Timestamp getDateTime() {
		return dateTime;
	}


	public void setDateTime(Timestamp dateTime) {
		this.dateTime = dateTime;
	}


		
	public static Double slidingWindowAverage(List<SlidingWindowQueue> listOfRecords,int windowLength) {

		int endIndex = listOfRecords.size(); //The sliding window ends at the timestamp of the last record. 
											 //List maintains the insertion order(same as order of timestamp in this case)
		
		int beginIndex = listOfRecords.size() - windowLength; //beginning is at lastTimestamp � windowLength
		
		int sum=0;
		int count = 0;
		for(int i=beginIndex;i<endIndex;i++) {
			
			SlidingWindowQueue windowRecord = listOfRecords.get(i);
			int value = windowRecord.getValue();
			sum = sum+value;
			count++;
		}
		
		Double slidingWindowAverage = (double) (sum/count);
		
		return slidingWindowAverage;
	}
}
