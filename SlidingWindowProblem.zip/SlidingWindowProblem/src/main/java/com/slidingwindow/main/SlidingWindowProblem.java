package com.slidingwindow.main;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class SlidingWindowProblem {

	public static List<SlidingWindowQueue> listOfDataRecords = new ArrayList<SlidingWindowQueue>();
	
	public static void main(String[] args) {		
		
		startProcess(args);
		
	}
	
	
	public static void startProcess(String[] args) {

		
		int dataRecordValue = 0;
		int slidingWindowLength = 0;
		Double valueAverage = 0.0;
		// assuming the series of record "Value" will be received from arguments
		// Value as first argument at index 0, windowLength as second argument at index 1
		// Timestamp will be recorded as current timestamp
		if (args != null && args.length == 2) {

			String inputValue = args[0];
			String inputWindowLength = args[1];

			try {
				dataRecordValue = Integer.parseInt(inputValue);
				slidingWindowLength = Integer.parseInt(inputWindowLength);
			} catch (NumberFormatException exception) {

				System.out.println("Error while parsing input arguments. Please pass correct argument data types");
			}

			// perform average operation
			if (listOfDataRecords.isEmpty()) {
				SlidingWindowQueue dataRecord = new SlidingWindowQueue();
				dataRecord.setValue(dataRecordValue);
				dataRecord.setDateTime(new Timestamp(System.currentTimeMillis()));
				listOfDataRecords.add(dataRecord);
				valueAverage = (double) dataRecordValue;
			} else {
				int sum = 0;
				int count = 0;
				SlidingWindowQueue dataRecord = new SlidingWindowQueue();
				dataRecord.setValue(Integer.parseInt(inputValue));
				dataRecord.setDateTime(new Timestamp(System.currentTimeMillis()));
				if (listOfDataRecords.size() < slidingWindowLength) {
					for (int i = 0; i <= listOfDataRecords.size(); i++) {

						SlidingWindowQueue windowRecord = listOfDataRecords.get(i);
						int value = windowRecord.getValue();
						sum = sum + value;
						count++;
					}

					Double slidingWindowAverage = (double) (sum / count);
					valueAverage = slidingWindowAverage;
				} else {
					valueAverage = SlidingWindowQueue.slidingWindowAverage(listOfDataRecords, slidingWindowLength);
				}
				listOfDataRecords.add(dataRecord);
			}
			System.out.println("value average over a sliding time window is:" + valueAverage);
		} else {
			System.out.println("Please pass correct input record as arguments. Value(Integer) as first argument and windowLength as second argument");
		}

	
	}
}
