package com.slidingwindow.test;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.slidingwindow.main.SlidingWindowQueue;

public class SlidingWindowProblemTest {

	
	@Test
	public void slidingWindowAverageTest() {
		
		List<SlidingWindowQueue> listOfDataRecords = new ArrayList<SlidingWindowQueue>();
		
		//assuming List has more than 3 data records and window size is 3
		
		SlidingWindowQueue dataRecord1 = new SlidingWindowQueue();
		dataRecord1.setValue(1);
		dataRecord1.setDateTime(new Timestamp(System.currentTimeMillis()));
		listOfDataRecords.add(dataRecord1);
		
		
		SlidingWindowQueue dataRecord2 = new SlidingWindowQueue();
		dataRecord2.setValue(2);
		dataRecord2.setDateTime(new Timestamp(System.currentTimeMillis()));
		listOfDataRecords.add(dataRecord2);
		
		SlidingWindowQueue dataRecord3 = new SlidingWindowQueue();
		dataRecord3.setValue(3);
		dataRecord3.setDateTime(new Timestamp(System.currentTimeMillis()));
		listOfDataRecords.add(dataRecord3);
		
		SlidingWindowQueue dataRecord4 = new SlidingWindowQueue();
		dataRecord4.setValue(4);
		dataRecord4.setDateTime(new Timestamp(System.currentTimeMillis()));
		listOfDataRecords.add(dataRecord4);
		
		SlidingWindowQueue dataRecord5 = new SlidingWindowQueue();
		dataRecord5.setValue(5);
		dataRecord5.setDateTime(new Timestamp(System.currentTimeMillis()));
		listOfDataRecords.add(dataRecord5);
		
		Double valueAverage = SlidingWindowQueue.slidingWindowAverage(listOfDataRecords, 3);
		
		System.out.println("valueAverage for dataRecord seriew window:{"+dataRecord1.getValue()+","+dataRecord2.getValue()+","+dataRecord3.getValue()
				+","+dataRecord4.getValue()+","+dataRecord5.getValue()+"} is:"+valueAverage);
		
	}
}
